from socket import*
import struct
import pymysql
s=socket(AF_INET,SOCK_DGRAM)
s.bind(('0.0.0.0',8887))
st=struct.Struct('i32sif')
db=pymysql.connect('localhost','root','123456','stud_list',encoding='utf-8')
cursor=db.cursor()#创建游标
while True:
    data,addr=s.recvfrom(1024)
    data=st.unpack(data)
    print(data[0],data[1],data[2],data[3])
    id=data[0]
    name=data[1].decode()
    age=data[2]
    score=data[3]
    sql="insert into stu_msg values(%d,'%s',%d,%f)"%(id,name,age,score)
    try:
        cursor.execute(sql)
        db.commit()#事务结束
    except Exception as e:
        db.rollback()#回滚
        print(e)
    else:
        cursor.close()
s.close()


from socket import *
from select import *

# 创建套接字作为关注的IO
s = socket()
s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 8888))
s.listen(5)
p = epoll()
fdmap = {s.fileno():s}
p.register(s, EPOLLIN | EPOLLERR)

# 添加IO到关注的列表
while True:
    # 监控IO
    events = p.poll()
    for fd, event in events:
        if fd ==s.fileno():
            c,addr = fdmap[fd].accept()
            print("Connect from", addr)
            p.register(c, EPOLLIN | EPOLLHUP)
            fdmap[c.fileno()] = c
        elif event & EPOLLHUP:
            print("客户端退出")
            p.unregister(fd)
            fdmap[fd].close()
            del fdmap[fd]
        elif event & EPOLLIN:
            data = fdmap[fd].recv(1024)
            print(data.decode())
            fdmap[fd].send(b'OK')
